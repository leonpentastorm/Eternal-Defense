Eternal Defense - Raider Gates - project 0.0.14 - local test build
Minecraft 1.20.1 / Forge 47.4.20 / Java 17. Network protocol 28 (unchanged from the 0.0.11 test build; no packet was
added). Install this build on the client AND the server: it adds one entity type (the gate).

Start a FRESH world for this feature. Keep existing worlds separate from this test instance.
Choose ONE folder: pack for the matching Create/KubeJS pack, or standalone.
Install all FOUR JARs from that folder on both client and server, replacing old
versions. Never mix pack and standalone editions or keep duplicate mod IDs.
TaCZ Attributes 1.4 is a required backend and is INCLUDED separately (unchanged since v4).
Also install TaCZ 1.1.8-hotfix2 (existing dependency, not included):
https://www.curseforge.com/minecraft/mc-mods/timeless-and-classics-zero/files/9037989
The pack folder requires the matching full pack's Create/KubeJS and scripts.
This ZIP is an update/test bundle, not a complete modpack.

WHAT IS IN IT
This is the latest build. Raider Gates (0.0.14) are the upgraded version of the stuck-raider rescue of 0.0.13, so
both are in here: the 0.0.13 progress timer, busy rules, ladder and spawn checks, with the silent teleport replaced
by a visible gate. See docs/GAME-DESIGN-DOCUMENT.md section 5.2 and docs/CHANGELOG.md.

* Raider Gates. A ground raider that walks up to lava or magma, a drop of 6 or more blocks or 8 or more blocks of
  water in a row (a short pond is waded), or that makes no progress for 25 seconds (and is not fighting, shooting or
  digging), stops and channels for 8 seconds beside a red gate (the Return portal sprite, tinted red). You can shoot the
  channeler: every second it is hurt adds 3 seconds, 10 at most; killing it cancels the gate. About 3 seconds before it
  reappears the exit shows portal particles and a sound. It comes out at the edge of the staging ring, at least 24 blocks
  from every player, and marches again. Raiders stuck in one place share one gate (8 channel, the rest wait). After
  three gates a raider is withdrawn (one chat line per wave); a raid boss is gated again and never withdrawn.
  Raiders still march straight: their pathfinding is unchanged. Flyers, gliders, paratroopers under a parachute and
  Special Forces soldiers are not covered.
* Mess Hall: cooking a stew over the stew still in a pot now asks first (Replace stew / Keep it / Escape). Stew
  servings per pot are now 3 / 5 / 7 / 9 for Mk I to Mk IV (the Mk IV value, 9, was asked for; the rest of the ladder
  was scaled to match and is one line in MealRules.tier). The Cook Pot's lamp bar gives light and its board text is
  drawn bright, so you can read the menu in the dark (from the front side).
* Field Guide: the Raids card has one line about the red gate; the Mess Hall and Cook Pot cards quote the new servings
  and the replace question.

HOW TO LOOK AT IT
* Start a raid near lava, a cliff edge or a wide lake and watch the raiders that stop at it (they will not walk in).
  Add -Darsenal.stuckLog=true to the game's JVM arguments and the log gets one "[stuck] event=..." line for every
  trigger, channel, teleport, cancel and withdrawal, with the terrain around the raider.
* -Darsenal.stuckTests=true registers the opt-in GameTests and the /stuck-raider-test command (permission level 2).
  They force-load and build a large stone platform far from spawn (chunk x 750): use a THROWAWAY world only.

LesRaisins Tactical Equipements 0.4.3 is OPTIONAL and not included.
Apocalypse gunpack and AppleSkin were not used in this round and are not redistributed.

See docs/RAIDER-GATES-TESTING.md for the checks that were actually run and what was not. Not tested, among others: a
real raid on real terrain, the red particle ring and the sounds (never seen or heard), a dedicated server, two players
near a destination, the standalone kitchen after this change, the legacy v2 to v6 GameTests.
JAR versions remain 0.21.0 / 1.1.0; use SHA512SUMS to identify this build.
Feature branch: feature/raider-gates (based on feature/stuck-raiders). This is not a public release.
