Eternal Defense - Mess Hall v6 - project 0.0.7 - local test build
Minecraft 1.20.1 / Forge 47.4.20 / Java 17. Network protocol 26.

Start a FRESH world for this feature. Keep existing worlds separate from this test instance.
Choose ONE folder: pack for the matching Create/KubeJS pack, or standalone.
Install all FOUR JARs from that folder on both client and server, replacing old
versions. Never mix pack and standalone editions or keep duplicate mod IDs.
TaCZ Attributes 1.4 is the newly required backend and is INCLUDED separately.
Also install TaCZ 1.1.8-hotfix2 (existing dependency, not included):
https://www.curseforge.com/minecraft/mc-mods/timeless-and-classics-zero/files/9037989
The pack folder requires the matching full pack's Create/KubeJS and scripts.
This ZIP is an update/test bundle, not a complete modpack.

LesRaisins Tactical Equipements 0.4.3 is OPTIONAL and not included.
Other attribute/affix frameworks are not required by Mess Hall.
Apocalypse gunpack and AppleSkin were used in local QA, not redistributed.
Fuel-reload guns (including bf1:ef46) cannot be crafted at Universal tables.
Ordinary is the default. Mix guide explicitly selects normal/legendary effects.
Base bread is separate; it adds no Grain. Every ordinary effect has a vanilla x2 pair.
Mk IV stew alone unlocks doubling; legendary doubling uses four distinct foods.
Milk Dispenser: 8,000 mB; each 250 mB drink clears ALL effects and saved meals.
Empty both hands, crouch and right-click to open either dispenser stock menu.
Craft four Milk Bottles from one milk bucket and four bottles; bucket returned.
Beacon Settings is beside Guide; all eleven fabrication cards show materials.
Animated links identify the two food groups and the resulting legendary buff.

See docs/MESS-HALL-V6-TESTING.md for actual checks and remaining playtests.
See docs/RAID-ADAPTATION.md for traps, wave resistance and weapon exclusions.
Custom gunpack scripts and source-erasing turrets need individual review.
JAR versions remain 0.21.0 / 1.1.0; use SHA512SUMS to identify this build.
Feature branch: feature/messhall-ver-6. This is not a public release.
