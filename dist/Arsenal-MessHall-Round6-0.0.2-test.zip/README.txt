Eternal Defense - Mess Hall Round 6 test build
Project update 0.0.2 | Minecraft 1.20.1 | Forge 47.4.20 | Java 17
Network protocol: 22-pack / 22-standalone

Install exactly ONE edition. Replace the previous versions of these JARs;
do not install pack and standalone copies together. The JAR build versions
remain 0.21.0 and 1.1.0; this is project update 0.0.2 with new protocol 22.
All clients and the server must use matching edition/builds.

standalone/: requires TaCZ; tested with TaCZ 1.1.8-hotfix2. Create/KubeJS
are optional. Gun Guide is client-only. Gun Displays is optional for Beacon.
pack/: requires TaCZ, Create, KubeJS and the full curated pack. Full-pack
integration has not been exercised in this development environment.
Third-party dependencies are not included.

Craft a Mess Hall Mk I and a Cook Pot with their vanilla recipes, then place
both entirely inside a standing beacon's territory. Hall: 2x2x1; pot: 2x1x1.
Open the hall, put at least two ingredients in the input slots and choose
Sandwich or Stew. Sandwich requires a staple (bread, wheat, baked potato);
its physical output carries up to two effects. Stew supports up to three
effects and stocks one selected empty linked pot within eight blocks.
Use a normal bowl on a filled pot to eat a serving; the bowl is reusable.
The field guide includes the full Mess Hall instructions.

Mk I/II/III/IV: 1/2/3/4 pots and 4/8/12/16 servings. Upgrade in the hall menu:
pack costs 8/16/32 Reinforced Plating; standalone 4/8/14 Ardent Energy.
Food, output and links are preserved when upgrading.

Meals last 30 minutes of field time. Home: double strength, timer frozen.
Returning home freezes the remainder without refreshing it. Logout/restart
pause duration. New meals replace old ones. Death clears meal bonuses.

Validation: all modules and both flavors build; 61 beacon and 7 gun-guide
unit tests pass. Real Forge tests exercise shared cooking/serving, footprints,
composition, timers, owned buffs, payment, raid repair and save state.
An actual restart and chunk unload/reload preserved servings and links.
A real client/server smoke checked both menus, pot serving and frozen versus
counting HUD state, including reduced frozen time after returning home.
This does not establish a complete two-human/Essential or full-pack playtest.

Art is functional vanilla-texture placeholder art. Painted replacements,
long co-op balance and exhaustive GUI/localization/optional-mod testing
remain playtest work. See MESS-HALL.md and GAME-DESIGN-DOCUMENT.md.
