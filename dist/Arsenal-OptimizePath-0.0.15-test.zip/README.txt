Eternal Defense - Optimize Path - project 0.0.15 - local test build
Minecraft 1.20.1 / Forge 47.4.20 / Java 17. Network protocol 28 (unchanged since the 0.0.11 test build; no packet was
added or changed). Install this build on the client AND the server.

Start a FRESH world for this feature. Keep existing worlds separate from this test instance.
Choose ONE folder: pack for the matching Create/KubeJS pack, or standalone.
Install all FOUR JARs from that folder on both client and server, replacing old
versions. Never mix pack and standalone editions or keep duplicate mod IDs.
TaCZ Attributes 1.4 is a required backend and is INCLUDED separately (unchanged since v4).
Also install TaCZ 1.1.8-hotfix2 (existing dependency, not included):
https://www.curseforge.com/minecraft/mc-mods/timeless-and-classics-zero/files/9037989
The pack folder requires the matching full pack's Create/KubeJS and scripts.
This ZIP is an update/test bundle, not a complete modpack.

WHAT IS IN IT
This is the latest build: everything of 0.0.14 (Raider Gates, the stew replace question, the lit Cook Pot board,
3/5/7/9 servings) plus the Optimize Path. The Optimize Path changes NO rule, number, screen or raid behaviour; it makes
the code that runs during play do less work for the same result (see docs/OPTIMIZE-PATH.md):
* the beacon's TaCZ bullet-impact hook listens to TaCZ's own event instead of every event of the game;
* the base score (computed about every 20 seconds between raids and at every raid start) is much cheaper, same score;
* gun-pack resource paths are checked without a regular expression (resource loading);
* the Special Forces corpse sweep is skipped when that optional mod is not installed;
* deaths outside a raid skip an id lookup.

WHAT TO LOOK FOR
Everything should play exactly as 0.0.14. Worth a look: a bullet from a hostile gunner hitting the beacon still damages
it; the Score / building tier shown in the beacon panel is the same as before for the same base; raids start as before.
-Darsenal.optimizeTests=true registers the opt-in /optimize-path-test command (permission level 2). It borrows the
campaign of a world WITHOUT a beacon: use a THROWAWAY world only.

LesRaisins Tactical Equipements 0.4.3 is OPTIONAL and not included.
Apocalypse gunpack and AppleSkin were not used in this round and are not redistributed.

See docs/OPTIMIZE-PATH-TESTING.md for the checks that were actually run, the measured numbers and what was not tested.
JAR versions remain 0.21.0 / 1.1.0; use SHA512SUMS to identify this build.
Feature branch: feature/optimize-path (based on feature/raider-gates). This is not a public release.
