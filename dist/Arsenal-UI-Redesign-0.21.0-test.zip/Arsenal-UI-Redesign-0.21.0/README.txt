Arsenal UI redesign - test build (0.21.0, branch claude/minecraft-mod-ui-guidebook-ak57k4)

Install ONE edition of each mod, never both (same mod IDs).
  standalone/mods/  -> needs TaCZ 1.1.8 (hotfix 2). Create/KubeJS/JEI optional.
  pack/mods/        -> for the full Create Arsenal pack (needs Create + KubeJS + TaCZ).
Use a separate/test world. Remove the old arsenal-*.jar files first.
Only the UI, text, icons and display names changed; saves are unaffected.
Not yet playtested in a real game with TaCZ - please report anything odd.
