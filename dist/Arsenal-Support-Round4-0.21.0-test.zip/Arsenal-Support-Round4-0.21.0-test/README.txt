Test build, support round 4 (network protocol 20: client and server must match).
standalone/ = standalone edition jars, pack/ = modpack edition jars (needs Create/KubeJS as before).
Fixed: the cannon now really turns (and grinds) before any call fires, and the turning time comes before the supply delay; the red area box is edges only (nothing hides behind it);
the Exchange Shop's crates no longer vanish at some angles; the parachute is a real, bigger canopy.
New: "Barrage in process", "Cannon preparing..." / "You heard cannon fire roaring", Bunker Buster digs its whole box and is the only support that hurts players (half health),
Area of Effect and Dimensional Link cannon upgrades, fire support icons (menu, banner above the hotbar), owner nameplates, Support Platform and Exchange Shop sold in the weapon table's Workshop tab,
cannon and platform can stand anywhere inside the beacon zone.
Old saves: upgrades and choices keep working (the save format grew from 8 to 10 upgrades without changing).
See docs/ENERGY-AND-SUPPORT.md in the source.
