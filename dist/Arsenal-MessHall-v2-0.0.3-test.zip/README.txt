Eternal Defense - Mess Hall v2 feature test build (project 0.0.3)
Branch: feature/messhall-ver-2. Not merged into dev.
Network protocol: 23-pack / 23-standalone. Match client/server edition and protocol.
Minecraft 1.20.1, Forge 47.4.20, Java 17, TaCZ 1.1.8-hotfix2.
Install either pack/ or standalone/ JARs, never both. Replace old versions.
Pack additionally requires the project's Create/KubeJS dependencies.
Standalone has no Create/KubeJS requirement. Gun Displays is optional for Beacon.
JAR build versions remain 0.21.0 / 1.1.0; VERSION identifies the project update.

Stew: 4/7/10/12 ingredient items for 4/8/12/16 servings. Sandwich: staple +
one/two fillings. Different item types score once; quantity funds the batch.
Firepower +5% gun damage, Quick Hands +6% reload speed, Brawler +15% gun bash
damage, Heavy Hand +12% bash knockback, Demolition +5% grenade/rocket radius
(base FIELD values). HOME doubles and freezes duration; re-entry does not refill.
Vanilla sources: beef, honey, pork, golden carrot, pufferfish respectively.
Demolition covers native TaCZ M320/RPG launcher paths; separate thrown grenades,
unrelated explosives and custom scripts bypassing native hooks are unsupported.

See MESS-HALL.md for full mechanics/IDs/hooks; validation JSON for actual checks
and remaining playtests. Functional art placeholders remain. This is a test build.
