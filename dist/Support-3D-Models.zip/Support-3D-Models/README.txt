Support gear 3D models (Minecraft Java block-model JSON, openable in Blockbench: File > Open Model).
All models use ONE texture, textures/support_kit.png (512x512 tile kit). In Blockbench, if the texture shows as missing, drag support_kit.png onto the model.

support_cannon.json          static base, 3x3x2 blocks (x/z -16..32)
support_cannon_turret.json   the turret; the game rotates it around the block centre and draws it 1.25x
support_cannon_barrel.json   the barrel, modelled flat along -Z; the game hinges it at (8,8,24), pitches it 50 degrees and slides it back on recoil
support_platform_mk1..4.json support platform per Mk level (front faces north)
exchange_shop.json           exchange shop (front faces north)
support_parcel.json / _chute.json  parcel chest and parachute
return_portal.png            4-frame 16x32 portal sheet (not a model)

Source generator: tools/ui-assets/models.py and kit.py in the repository. To export OBJ/glTF use Blockbench's File > Export.
