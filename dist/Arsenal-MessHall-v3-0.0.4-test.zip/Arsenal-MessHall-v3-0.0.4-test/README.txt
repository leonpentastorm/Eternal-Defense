Eternal Defense 0.0.4 - Mess Hall v3 test build (network protocol 24: client and server must match; feature branch feature/messhall-ver-3, not merged into dev).
standalone/ = standalone edition jars, pack/ = modpack edition jars. Do not install both.

New: painted Mess Halls (2 wide, 2 tall, 1 deep) and Cook Pot (1 x 1 x 2) from the artist package, with their own item icons.
Meals now show as ordinary potion effects (value and time in the inventory list) plus a Home Zone effect ("your food buffs double and don't decay"); the old meal HUD is gone.
Sixteen meal effects, a trait for every vanilla food, and a x2 pair bonus when a stew has two different foods of one family. Redesigned kitchen screen.
Gun food effects (Firepower, Quick Hands, Brawler, Heavy Hand, Demolition) were checked against real TaCZ: they work; their values were raised (8/10/20/15/10 percent) so they can be felt.
Raids: raiders march straight at the beacon and dig only when blocked, spawn on open surface ground at or above the beacon, carry a red exclamation mark and do not burn in sunlight.
Air raids: phantoms and vexes fly straight at the beacon. Siege: creepers dig at walls near the base. Paratroopers: every one wears a parachute.
The platform sign's post is visible from every angle.
Old saves keep working: meals, pots and halls keep their data (a stew made before this build has no pair bonus).
See docs/MESS-HALL.md, docs/HANDOFF.md and docs/MESS-HALL-VALIDATION-0.0.4.json in the source for what was and was not tested.
