Eternal Defense - Mess Hall v6 UI pass - project 0.0.8 - local test build
Minecraft 1.20.1 / Forge 47.4.20 / Java 17. Network protocol 27.

Start a FRESH world for this feature. Keep existing worlds separate from this test instance.
Choose ONE folder: pack for the matching Create/KubeJS pack, or standalone.
Install all FOUR JARs from that folder on both client and server, replacing old
versions. Never mix pack and standalone editions or keep duplicate mod IDs.
TaCZ Attributes 1.4 is a required backend and is INCLUDED separately (unchanged since v4).
Also install TaCZ 1.1.8-hotfix2 (existing dependency, not included):
https://www.curseforge.com/minecraft/mc-mods/timeless-and-classics-zero/files/9037989
The pack folder requires the matching full pack's Create/KubeJS and scripts.
This ZIP is an update/test bundle, not a complete modpack.

WHAT CHANGED (see docs/MESS-HALL-V7-UI.md)
* Mess Hall on one screen: click recipe icons (everyday on top, legendary gun effects below),
  press Gather ingredients, press Make sandwich / Cook stew. Take back returns the table.
  The Mix guide screen is gone. Your order and sandwich/stew mode stay with the hall.
* Bowl Dispenser and Milk Dispenser tell you what happened (bowls left, what the milk cleared,
  milk left) with sound and particles. Milk is no longer spent when you have no effects.
* Dispenser screens, Workshop Fabrication, the weapon-table Upgrade view and three Field Guide
  pages were restyled.
Rules, numbers, recipes and the economy are unchanged from the v6 build.

Empty both hands, crouch and right-click to open either dispenser stock screen.
LesRaisins Tactical Equipements 0.4.3 is OPTIONAL and not included.
Apocalypse gunpack and AppleSkin were not used in this round and are not redistributed.

See docs/MESS-HALL-V7-TESTING.md for the checks that were actually run and what was not.
JAR versions remain 0.21.0 / 1.1.0; use SHA512SUMS to identify this build.
Feature branch: feature/messhall-ver-6. This is not a public release.
