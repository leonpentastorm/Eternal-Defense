Eternal Defense - Field Guide for new players - project 0.0.10 - local test build
Minecraft 1.20.1 / Forge 47.4.20 / Java 17. Network protocol 27 (unchanged).

Start a FRESH world for this feature. Keep existing worlds separate from this test instance.
Choose ONE folder: pack for the matching Create/KubeJS pack, or standalone.
Install all FOUR JARs from that folder on both client and server, replacing old
versions. Never mix pack and standalone editions or keep duplicate mod IDs.
TaCZ Attributes 1.4 is a required backend and is INCLUDED separately (unchanged since v4).
Also install TaCZ 1.1.8-hotfix2 (existing dependency, not included):
https://www.curseforge.com/minecraft/mc-mods/timeless-and-classics-zero/files/9037989
The pack folder requires the matching full pack's Create/KubeJS and scripts.
This ZIP is an update/test bundle, not a complete modpack.

WHAT CHANGED (see docs/FIELD-GUIDE-TESTING.md and docs/GUIDE-STYLE.md)
* The Field Guide is rewritten for somebody who has just spawned in. Every feature is a card:
  what it is, what you get, how it works, how to unlock it, and red Careful notes for the catches
  (for example: the beacon only comes off with the Recovery Shovel and that resets the whole campaign).
* The Field Guide's side menu is back in every window size, with an item icon for each page
  (a list with titles when there is room, a two-column icon rail with hover names when there is not).
* New page "Extra gun mods" for Gun Guide and Gun Displays; many features that had no explanation now do.
* The plant confirmation and the Defense Beacon tooltip warn about the reset. The standalone upgrade
  hint now says Ardent Energy (it used to say "craft it").
* Exact numbers stay in the Reference page. Rules, numbers, recipes and the economy are unchanged.
Everything else is the Mess Hall v6 UI pass (0.0.8).

LesRaisins Tactical Equipements 0.4.3 is OPTIONAL and not included.
Apocalypse gunpack and AppleSkin were not used in this round and are not redistributed.

See docs/FIELD-GUIDE-TESTING.md for the checks that were actually run and what was not.
JAR versions remain 0.21.0 / 1.1.0; use SHA512SUMS to identify this build.
Feature branch: feature/messhall-ver-6. This is not a public release.
