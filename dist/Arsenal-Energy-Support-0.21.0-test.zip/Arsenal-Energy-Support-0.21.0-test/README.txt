Test build: UI redesign + Ardent Energy, Exchange Shop and base support (protocol 17: client and server must match).
standalone/ = standalone edition jars, pack/ = modpack edition jars (needs Create/KubeJS as before).
Config files appear in config/: arsenal-beacon-common.toml, arsenal-beacon-exchange.txt, arsenal-beacon-support-costs.txt.
See docs/ENERGY-AND-SUPPORT.md in the source for rules and what was tested.
