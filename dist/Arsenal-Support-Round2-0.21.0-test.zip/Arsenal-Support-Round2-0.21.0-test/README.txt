Test build, support round 2 (network protocol 18: client and server must match; the first support test build was 17).
standalone/ = standalone edition jars, pack/ = modpack edition jars (needs Create/KubeJS as before).
Support gear is per player and only works inside a standing Defense Beacon's zone; move it with the Beacon Recovery Shovel.
Old support blocks from the first test build have no owner: pick them up with the shovel and place them again.
Config files appear in config/: arsenal-beacon-common.toml, arsenal-beacon-exchange.txt (the support-costs file is gone).
See docs/ENERGY-AND-SUPPORT.md in the source.
