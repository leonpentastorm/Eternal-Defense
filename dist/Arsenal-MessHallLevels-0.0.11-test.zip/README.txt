Eternal Defense - Mess Hall levels and table upgrade - project 0.0.11 - local test build
Minecraft 1.20.1 / Forge 47.4.20 / Java 17. Network protocol 28 (was 27): every client and the server
must run this build. An older client is refused at login.

Start a FRESH world for this feature. Keep existing worlds separate from this test instance.
Choose ONE folder: pack for the matching Create/KubeJS pack, or standalone.
Install all FOUR JARs from that folder on both client and server, replacing old
versions. Never mix pack and standalone editions or keep duplicate mod IDs.
TaCZ Attributes 1.4 is a required backend and is INCLUDED separately (unchanged since v4).
Also install TaCZ 1.1.8-hotfix2 (existing dependency, not included):
https://www.curseforge.com/minecraft/mc-mods/timeless-and-classics-zero/files/9037989
The pack folder requires the matching full pack's Create/KubeJS and scripts.
This ZIP is an update/test bundle, not a complete modpack.

WHAT CHANGED (see docs/MESS-HALL-TIERS.md and docs/TIERS-AND-TABLES-TESTING.md)
* Mess Hall levels. Mk I: sandwiches only, meals last 15 minutes, 3 food slots.
  Mk II: unlocks stew, 20 minutes. Mk III: 25 minutes and x2 doubling (two DIFFERENT foods of one type
  make an effect count twice). Mk IV: 30 minutes and all 6 food slots, the only level that can double
  a legendary effect. The screen says all of this: chips for minutes, slots and x2, a padlock on Stew
  below Mk II, and plain tooltips.
* The Mess Hall screen is bigger (376 x 238) and split in two: everything you press to DO a task is on the
  left, every effect you can CHOOSE is on the right, on calm dimmed tiles. It needs a GUI at least 376
  pixels wide: 1280 x 720 works at GUI scale 3 or lower; on a 4:3 window lower the GUI scale.
* The Weapon, Ammo, Attachment and Armor tables upgrade with one big Upgrade button (an Age ladder, the next
  Age and the materials you hold), like the Mess Hall and the Supply Platform. The blank left side is gone.
* Field Guide: new "Mess Hall levels" and "Doubling (x2)" cards, and the Ages card describes the one button.
Rules for the other systems, recipes and the economy are unchanged. The Field Guide side menu (0.0.10) and
the Mess Hall v6 UI pass (0.0.8) are included.

LesRaisins Tactical Equipements 0.4.3 is OPTIONAL and not included.
Apocalypse gunpack and AppleSkin were not used in this round and are not redistributed.

See docs/TIERS-AND-TABLES-TESTING.md for the checks that were actually run and what was not.
JAR versions remain 0.21.0 / 1.1.0; use SHA512SUMS to identify this build.
Feature branch: feature/messhall-ver-6. This is not a public release.
