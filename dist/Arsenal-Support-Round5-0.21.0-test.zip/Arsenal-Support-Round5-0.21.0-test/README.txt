Test build, support round 5 (network protocol 21: client and server must match).
standalone/ = standalone edition jars, pack/ = modpack edition jars (needs Create/KubeJS as before).
Fixed: the beacon zone outline no longer goes stale during a lag spike (best guess for the flicker, which could not be reproduced here).
New: the beacon is the reward chest; Bunker Buster spares obsidian, crying obsidian, bedrock and other blast-proof blocks;
Ardent Energy drops about one in fifteen kills (bosses always, every won raid pays a guaranteed share);
the Exchange buys and sells in two tabs (pack: Create parts, standalone: rare vanilla materials);
the economy is re-priced (pack: upgrades cost factory parts, energy buys flares and Exchange goods; standalone: everything in energy, slightly higher drops);
the platform's name plate is a crooked sign above it, the two blocks in front are a no-build return zone, a blocked return uses a safe spot or is cancelled before the flare is spent;
four special raid types from the fourth raid on (Air raid, Paratroopers, Siege, They are thousands).
Testing (operators): /arsenal next-raid <normal|air|paratroopers|siege|swarm>, and /arsenal test-raid <type> to start one at once (the introduction raid is always ordinary).
See docs/ENERGY-AND-SUPPORT.md in the source for what was and was not tested.
