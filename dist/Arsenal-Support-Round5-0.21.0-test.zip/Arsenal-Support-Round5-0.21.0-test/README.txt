Test build, support round 5 (network protocol 21: client and server must match).
standalone/ = standalone edition jars, pack/ = modpack edition jars (needs Create/KubeJS as before).
Fixed: the beacon zone outline no longer goes stale during a lag spike (best guess for the flicker, which could not be reproduced here).
New: the beacon is the reward chest (no chest block placed); Bunker Buster spares obsidian, crying obsidian, bedrock and other blast-proof blocks;
Ardent Energy drops about one in fifteen kills (bosses always, every won raid pays a guaranteed share);
the Exchange buys and sells in two tabs (pack: Create parts, standalone: rare vanilla materials);
the whole economy is re-priced: in the pack, cannon and beacon upgrades and repairs cost the pack's factory parts and energy only buys flares and Exchange goods; the standalone edition pays everything in energy and drops a bit more;
the platform's name plate is a crooked sign on a post above it (no hitbox), the two blocks in front of the platform are a no-build return zone, and a blocked return uses a nearby safe spot or is cancelled before the flare is spent;
four special raid types from the fourth raid on (Air raid, Paratroopers under red parachutes, Siege, They are thousands), announced at the end of each raid and shown in the Overview.
Old saves: upgrade levels and choices keep working. An old exchange file is kept as .old.txt and replaced by the new [sell]/[buy] file.
See docs/ENERGY-AND-SUPPORT.md in the source for what was and was not tested.
