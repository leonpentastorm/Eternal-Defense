Test build, support round 3 (network protocol 19: client and server must match).
standalone/ = standalone edition jars, pack/ = modpack edition jars (needs Create/KubeJS as before).
New: your hand-made models (platform and shop are now 2 blocks tall), cannon menu (click the cannon): 6 fire support types chosen per player + 8 upgrades.
Old platforms/shops placed with the previous test builds are one block tall: pick them up with the Beacon Recovery Shovel and place them again.
See docs/ENERGY-AND-SUPPORT.md in the source.
