CREATE ARSENAL - KITCHEN EXTRAS
===============================
INSTALL
  minecraft-models/block/*.json -> assets/arsenal_beacon/models/block/
  minecraft-models/item/*.json  -> assets/arsenal_beacon/models/item/
  textures/block/*.png          -> assets/arsenal_beacon/textures/block/
  textures/item/*.png           -> assets/arsenal_beacon/textures/item/
  File names are suggestions - if your IDs differ, rename the JSON + PNG pair and the texture
  reference inside the JSON ("arsenal_beacon:block/<name>" or "arsenal_beacon:item/<name>").

BOWL DISPENSER  (bowl_dispenser, 2 tall x 1 x 1, front = north)
  Cook-pot family: olive body, gunmetal posts, brass bands, BOWLS header with an amber lamp.
  Open magazine column (two steel bars in front) showing a stack of nested wooden bowls,
  a dispensing mouth with a tray and one served bowl, pull lever with a red knob on the right side.
  If you pop the bowl out as an item/entity, spawn it at about (8, 3.5, 1.5).

MILK DISPENSER  (milk_dispenser, 2 tall x 1 x 1, front = north)
  Cream milk tank with blue band, MILK lettering, sight gauge and brass filler cap on top;
  stainless PUSH head with nozzle over a grated drip tray holding a glass of milk;
  chilled lower cabinet with a stainless door and a cyan "cold" LED.
  The glass of milk is part of the model (always shown). If you want it to appear only when
  stocked, ask and I'll split it into its own multipart piece like the stew surface.

Both dispensers reach into the cell above (y 0..31.75): that cell must be an invisible filler,
same as the cook pot / shop / platforms. Normal (solid) render layer, no glass.

BEACON RECOVERY SHOVEL  (item model, models/item/beacon_recovery_shovel.json)
  Gunmetal shaft with a rubber T-grip and grip sleeve, hazard-striped wrap, a miniature beacon
  core in the collar (glowing cyan energy cell between brass rings and four struts), gunmetal
  spade with a cyan stripe, chrome edge and red shoulder lights (the beacon's antenna tips).
  Built along the same diagonal as a vanilla tool sprite (handle bottom-left, blade top-right)
  and uses the vanilla item/handheld transforms, so it's held exactly like a vanilla shovel.

PREPARED SANDWICH  (item model, models/item/prepared_sandwich.json)
  Toasted bread with grill marks, ruffled lettuce, tomato slices, cheddar slice turned 22.5 deg
  so the corners hang out (with drips), thick ham, bacon, and an olive on a pick with a little
  olive-drab flag. 3D food display transforms (tilted in the inventory slot, small in hand).

EDITING
  blockbench/*.bbmodel (texture embedded), blender/*.obj (X east, Y south, Z up, 1 unit = 1 block).
